/**
 * HM Café - Main Application Controller
 * Smart Table Reservation & Queue Management
 */

document.addEventListener("DOMContentLoaded", async () => {
    // 0. Check Backend Connection & Sync Data
    if (window.cafeStore) {
        await window.cafeStore.checkBackend();
    }

    // 1. Theme Management
    initTheme();

    // 2. Stat Counter Animations
    initCounters();

    // 3. Populate Dynamic Table Selection Dropdown
    populateTableSelect();

    // 4. Smart Floor Plan Initialization
    renderFloorPlan("all");

    // 5. Live Queue Management Rendering
    renderLiveQueue();

    // 6. Smart Screen Board Initialization
    renderSmartScreen();

    // 7. Analytics Charts Initialization
    initAnalyticsCharts();


    // 8. Admin Dashboard Rendering
    renderAdminDashboard();

    // 9. Event Listeners & Interactions
    setupEventListeners();

    // 10. Start Real-time Clock Ticker & ScrollSpy & DatePicker
    initClockTicker();
    initScrollSpy();
    initDatePicker();
});

/* ==========================================================================
   1. Theme Switcher Logic
   ========================================================================== */
function initTheme() {
    const savedTheme = localStorage.getItem("hm_cafe_theme") || "light";
    document.documentElement.setAttribute("data-theme", savedTheme);
    updateThemeIcon(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const newTheme = currentTheme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", newTheme);
    localStorage.setItem("hm_cafe_theme", newTheme);
    updateThemeIcon(newTheme);
    showToast(`Switched to ${newTheme.toUpperCase()} mode`, "info");
}

function updateThemeIcon(theme) {
    const icon = document.querySelector("#theme-toggle-btn i");
    if (icon) {
        icon.className = theme === "dark" ? "fas fa-sun" : "fas fa-moon";
    }
}

/* ==========================================================================
   2. Counter Animation Logic
   ========================================================================== */
function initCounters() {
    const counters = document.querySelectorAll(".counter-value");
    counters.forEach(counter => {
        const target = +counter.getAttribute("data-target");
        if (!target) return;
        let count = 0;
        const speed = target / 30;

        const updateCount = () => {
            count += speed;
            if (count < target) {
                counter.innerText = Math.ceil(count);
                setTimeout(updateCount, 40);
            } else {
                counter.innerText = target;
            }
        };
        updateCount();
    });
}

/* ==========================================================================
   3. Smart Floor Plan Engine (20 Tables)
   ========================================================================== */
let selectedTableId = null;

function renderFloorPlan(filterSection = "all") {
    const grid = document.getElementById("floor-plan-grid");
    if (!grid) return;

    const tables = window.cafeStore.getTables();
    grid.innerHTML = "";

    const filteredTables = filterSection === "all"
        ? tables
        : tables.filter(t => t.section === filterSection);

    filteredTables.forEach(table => {
        const card = document.createElement("div");
        card.className = `table-card status-${table.status} ${table.id === selectedTableId ? "selected" : ""}`;
        card.onclick = () => openTableModal(table.id);

        card.innerHTML = `
            <div class="table-number">${table.name}</div>
            <div class="table-badge">${table.status}</div>
            <div style="font-size: 0.8rem; color: var(--text-secondary);">
                <i class="fas fa-users"></i> ${table.capacity} Seats | ${table.section.toUpperCase()}
            </div>
        `;
        grid.appendChild(card);
    });
}

function openTableModal(tableId) {
    selectedTableId = tableId;
    renderFloorPlan(document.querySelector(".tab-btn.active")?.getAttribute("data-section") || "all");

    const tables = window.cafeStore.getTables();
    const table = tables.find(t => t.id === tableId);
    if (!table) return;

    const modalHtml = `
        <div class="modal-overlay active" id="table-modal">
            <div class="ticket-card" style="max-width: 440px;">
                <div class="ticket-header" style="display:flex; justify-content:space-between; align-items:center;">
                    <h3>${table.name} Details</h3>
                    <button onclick="closeModal('table-modal')" style="background:none; border:none; color:#fff; font-size:1.4rem; cursor:pointer;">&times;</button>
                </div>
                <div class="ticket-body">
                    <div class="ticket-info-row"><span>Section:</span> <span>${table.section.toUpperCase()}</span></div>
                    <div class="ticket-info-row"><span>Seating Capacity:</span> <span>${table.capacity} Guests</span></div>
                    <div class="ticket-info-row"><span>Current Status:</span> <span class="badge badge-${table.status === 'available' ? 'success' : table.status === 'occupied' ? 'danger' : 'warning'}">${table.status.toUpperCase()}</span></div>
                    <div class="ticket-info-row"><span>Guest Name:</span> <span>${table.guestName || "N/A"}</span></div>
                    <div class="ticket-info-row"><span>Reserved Time:</span> <span>${table.reservedTime || "N/A"}</span></div>

                    <div style="margin-top: 24px; display:flex; gap:10px; flex-direction:column;">
                        ${table.status === "available" ? `
                            <button class="btn btn-primary" onclick="quickReserveTable(${table.id})"><i class="fas fa-calendar-check"></i> Book This Table</button>
                            <button class="btn btn-secondary" onclick="updateTableStatus(${table.id}, 'occupied')"><i class="fas fa-user-check"></i> Mark Occupied</button>
                        ` : table.status === "occupied" ? `
                            <button class="btn btn-primary" onclick="updateTableStatus(${table.id}, 'available')"><i class="fas fa-check-circle"></i> Free & Clean Table</button>
                        ` : `
                            <button class="btn btn-primary" onclick="updateTableStatus(${table.id}, 'occupied')"><i class="fas fa-user-check"></i> Seat Customer Now</button>
                            <button class="btn btn-outline" onclick="updateTableStatus(${table.id}, 'available')"><i class="fas fa-times-circle"></i> Cancel Reservation</button>
                        `}
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById("modal-container").innerHTML = modalHtml;
}

function populateTableSelect() {
    const select = document.getElementById("res-table-select");
    if (!select) return;
    const tables = window.cafeStore.getTables();

    let html = `<option value="">Auto-Assign Best Available Table</option>`;
    tables.forEach(t => {
        const isAvail = t.status === "available";
        const label = `Table ${t.id < 10 ? '0' + t.id : t.id} (${t.section.toUpperCase()} - ${t.capacity} Seats) ${!isAvail ? '[' + t.status.toUpperCase() + ']' : '[AVAILABLE]'}`;
        html += `<option value="${t.id}" ${!isAvail ? 'disabled' : ''}>${label}</option>`;
    });
    select.innerHTML = html;
}

function updateTableStatus(tableId, newStatus) {
    const tables = window.cafeStore.getTables();
    const index = tables.findIndex(t => t.id === tableId);
    if (index !== -1) {
        tables[index].status = newStatus;
        if (newStatus === "available") {
            tables[index].guestName = null;
            tables[index].reservedTime = null;
        } else if (newStatus === "occupied" && !tables[index].guestName) {
            tables[index].guestName = "Walk-in Guest";
            tables[index].reservedTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        window.cafeStore.saveTables(tables);
        populateTableSelect();
        renderFloorPlan();
        renderAdminDashboard();
        closeModal('table-modal');
        showToast(`Table ${tables[index].name} is now ${newStatus.toUpperCase()}`, "success");
    }
}

function quickReserveTable(tableId) {
    closeModal('table-modal');
    populateTableSelect();
    const select = document.getElementById("res-table-select");
    if (select) select.value = tableId;
    document.getElementById("reservation").scrollIntoView({ behavior: 'smooth' });
    showToast(`Table #${tableId} pre-selected for reservation!`, "info");
}

/* ==========================================================================
   4. Reservation Form & Receipt Generator
   ========================================================================== */
async function handleReservationSubmit(e) {
    e.preventDefault();

    const name = document.getElementById("res-name").value.trim();
    const phone = document.getElementById("res-phone").value.trim();
    const email = document.getElementById("res-email").value.trim();
    const guests = parseInt(document.getElementById("res-guests").value, 10);
    const date = document.getElementById("res-date").value;
    const time = document.getElementById("res-time").value;
    const zone = document.querySelector('input[name="res-zone"]:checked')?.value || "Indoor";
    const selectedTableId = document.getElementById("res-table-select")?.value;
    const requests = document.getElementById("res-requests").value.trim();

    if (!name || !phone || !date || !time) {
        showToast("Please complete all required fields.", "danger");
        return;
    }

    const tables = window.cafeStore.getTables();
    let assignedTableNo = null;

    if (selectedTableId) {
        const targetTable = tables.find(t => t.id === parseInt(selectedTableId, 10));
        if (targetTable && targetTable.status === "available") {
            assignedTableNo = targetTable.id;
        } else {
            showToast(`Table #${selectedTableId} is unavailable. Auto-matching best seat.`, "warning");
        }
    }

    if (!assignedTableNo) {
        const zoneLower = zone.toLowerCase();
        let match = tables.find(t => t.status === "available" && t.section.toLowerCase() === zoneLower && t.capacity >= guests);
        if (!match) {
            match = tables.find(t => t.status === "available" && t.capacity >= guests);
        }
        if (!match) {
            match = tables.find(t => t.status === "available");
        }
        assignedTableNo = match ? match.id : Math.floor(1 + Math.random() * 20);
    }

    const resId = "RES-" + Math.floor(1000 + Math.random() * 9000);

    const newRes = {
        id: resId,
        name,
        phone,
        email,
        guests,
        date,
        time,
        section: zone,
        tableNo: assignedTableNo,
        status: "Confirmed",
        specialRequest: requests || "None"
    };

    await window.cafeStore.addReservation(newRes);

    // Reserve table in store
    const tIndex = tables.findIndex(t => t.id === assignedTableNo);
    if (tIndex !== -1 && tables[tIndex].status === "available") {
        tables[tIndex].status = "reserved";
        tables[tIndex].guestName = name;
        tables[tIndex].reservedTime = time;
        tables[tIndex].phone = phone;
        await window.cafeStore.saveTables(tables);
    }

    populateTableSelect();
    renderFloorPlan();
    renderAdminDashboard();
    showConfirmationReceipt(newRes);
    document.getElementById("reservation-form").reset();
    playChime();
    showSMSNotification(phone, `Your HM Café reservation #${resId} for Table #${assignedTableNo} on ${date} @ ${time} is confirmed!`);
    showToast("Reservation successfully booked!", "success");
}

function playChime() {
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        const ctx = new AudioContext();
        const now = ctx.currentTime;

        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(523.25, now);
        gain1.gain.setValueAtTime(0.12, now);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start(now);
        osc1.stop(now + 0.5);

        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(659.25, now + 0.12);
        gain2.gain.setValueAtTime(0.12, now + 0.12);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start(now + 0.12);
        osc2.stop(now + 0.7);
    } catch (e) {
        console.log("Audio play notice:", e);
    }
}

function showConfirmationReceipt(res) {
    const qrSvg = `
        <svg width="140" height="140" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="100" height="100" fill="#FFFFFF"/>
            <path d="M10 10H40V40H10V10ZM20 20V30H30V20H20Z" fill="#2D1E1B"/>
            <path d="M60 10H90V40H60V10ZM70 20V30H80V20H70Z" fill="#2D1E1B"/>
            <path d="M10 60H40V90H10V60ZM20 70V80H30V70H20Z" fill="#2D1E1B"/>
            <rect x="50" y="50" width="15" height="15" fill="#2D1E1B"/>
            <rect x="75" y="50" width="15" height="15" fill="#2D1E1B"/>
            <rect x="50" y="75" width="15" height="15" fill="#2D1E1B"/>
            <rect x="75" y="75" width="15" height="15" fill="#2D1E1B"/>
            <rect x="65" y="65" width="10" height="10" fill="#2D1E1B"/>
        </svg>
    `;

    const modalHtml = `
        <div class="modal-overlay active" id="receipt-modal">
            <div class="ticket-card">
                <div class="ticket-header">
                    <div class="badge badge-success" style="margin-bottom:8px;"><i class="fas fa-check-circle"></i> Booking Confirmed</div>
                    <h3>HM Café Pass</h3>
                    <p style="font-size:0.85rem; opacity:0.85;">Show this QR ticket upon arrival</p>
                </div>
                <div class="ticket-body">
                    <div style="text-align:center;">
                        <div class="qr-container">${qrSvg}</div>
                    </div>
                    <div class="ticket-info-row"><span>Reservation ID:</span> <span>${res.id}</span></div>
                    <div class="ticket-info-row"><span>Guest Name:</span> <span>${res.name}</span></div>
                    <div class="ticket-info-row"><span>Date & Time:</span> <span>${res.date} @ ${res.time}</span></div>
                    <div class="ticket-info-row"><span>Assigned Table:</span> <span>Table ${res.tableNo} (${res.section})</span></div>
                    <div class="ticket-info-row"><span>Party Size:</span> <span>${res.guests} Guests</span></div>

                    <div style="display:flex; gap:10px; margin-top:20px;">
                        <button class="btn btn-primary" onclick="window.print()" style="flex:1;"><i class="fas fa-print"></i> Print Ticket</button>
                        <button class="btn btn-secondary" onclick="navigator.clipboard.writeText('${res.id}'); showToast('Reservation ID copied!', 'info');" style="flex:1;"><i class="fas fa-copy"></i> Copy Code</button>
                    </div>
                    <button class="btn btn-outline" onclick="closeModal('receipt-modal')" style="width:100%; margin-top:10px;">Close Pass</button>
                </div>
            </div>
        </div>
    `;

    document.getElementById("modal-container").innerHTML = modalHtml;
}

/* ==========================================================================
   5. Live Queue Engine & Simulation
   ========================================================================== */
function renderLiveQueue() {
    const queueList = window.cafeStore.getQueue();
    const queueContainer = document.getElementById("queue-cards-container");
    if (!queueContainer) return;

    const waiting = queueList.filter(q => q.status === "Waiting");

    document.getElementById("current-serving-no").innerText = queueList.find(q => q.status === "Called")?.id || "Q-101";
    document.getElementById("total-waiting-count").innerText = waiting.length;

    queueContainer.innerHTML = queueList.slice(0, 5).map(q => `
        <div class="glass-card" style="padding: 20px; display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
            <div>
                <span class="badge ${q.status === 'Called' ? 'badge-success' : 'badge-warning'}">${q.status}</span>
                <h4 style="font-size:1.1rem; margin-top:4px;">${q.name} (${q.guests} Guests)</h4>
                <p style="font-size:0.85rem; color:var(--text-secondary);">ID: ${q.id} | Joined: ${q.timestamp}</p>
            </div>
            <div style="text-align:right;">
                <div style="font-family:var(--font-heading); font-weight:700; color:var(--primary-dark); font-size:1.1rem;">${q.estWait}</div>
                <span style="font-size:0.8rem; color:var(--text-muted);">Est. Wait</span>
            </div>
        </div>
    `).join("");
}

async function handleJoinWaitlist(e) {
    e.preventDefault();
    const name = document.getElementById("queue-name").value.trim();
    const phone = document.getElementById("queue-phone").value.trim();
    const guests = document.getElementById("queue-guests").value;

    if (!name || !phone) {
        showToast("Please fill in name and phone number.", "danger");
        return;
    }

    const queue = window.cafeStore.getQueue();
    const newQ = {
        id: "Q-" + (100 + queue.length + 1),
        name,
        phone,
        guests,
        estWait: `${(queue.filter(q => q.status === 'Waiting').length + 1) * 8} mins`,
        status: "Waiting",
        tableNo: "-",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    await window.cafeStore.addToQueue(newQ);
    renderLiveQueue();
    renderSmartScreen();
    renderAdminDashboard();
    closeModal("join-queue-modal");
    document.getElementById("join-queue-form").reset();
    showToast(`Joined queue! Your Queue ID is ${newQ.id}`, "success");
}

async function callNextInQueue() {
    const queue = window.cafeStore.getQueue();
    const nextWaiting = queue.find(q => q.status === "Waiting");

    if (!nextWaiting) {
        showToast("No customers currently in waiting queue.", "info");
        return;
    }

    const tables = window.cafeStore.getTables();
    const availableTable = tables.find(t => t.status === "available" && t.capacity >= nextWaiting.guests) || tables.find(t => t.status === "available");
    const assignedTable = availableTable ? availableTable.id : Math.floor(1 + Math.random() * 20);

    await window.cafeStore.updateQueueStatus(nextWaiting.id, "Called", assignedTable);

    if (availableTable) {
        availableTable.status = "reserved";
        availableTable.guestName = nextWaiting.name + " (Queue " + nextWaiting.id + ")";
        availableTable.reservedTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        await window.cafeStore.saveTables(tables);
    }

    playChime();
    populateTableSelect();
    renderFloorPlan();
    renderLiveQueue();
    renderSmartScreen();
    renderAdminDashboard();
    showSMSNotification(nextWaiting.phone, `Your Queue #${nextWaiting.id} is ready! Please proceed to Table #${assignedTable}.`);
    showToast(`Called Queue ${nextWaiting.id} - ${nextWaiting.name} to Table ${assignedTable}!`, "warning");
}

/* ==========================================================================
   6. Airport-Style Smart Display Board
   ========================================================================== */
function renderSmartScreen() {
    const board = document.getElementById("smart-screen-tbody");
    if (!board) return;

    const queue = window.cafeStore.getQueue();

    board.innerHTML = queue.map(item => `
        <tr>
            <td style="font-weight:bold; color:#00FFCC;">${item.id}</td>
            <td>${item.name}</td>
            <td style="color:#FFB703;">${item.tableNo !== '-' ? 'Table ' + item.tableNo : 'Pending'}</td>
            <td>
                <span class="status-badge-board ${item.status === 'Called' ? 'status-ready' : item.status === 'Waiting' ? 'status-serving' : 'status-completed'}">
                    ${item.status === 'Called' ? 'READY / SEATED' : item.status}
                </span>
            </td>
        </tr>
    `).join("");
}

function initClockTicker() {
    const clock = document.getElementById("smart-board-clock");
    if (!clock) return;
    setInterval(() => {
        clock.innerText = new Date().toLocaleTimeString();
    }, 1000);
}

/* ==========================================================================
   7. Peak Time Analytics Charts (Chart.js)
   ========================================================================== */
function initAnalyticsCharts() {
    const analytics = window.cafeStore.getAnalytics();

    // Chart 1: Hourly Reservations (Bar)
    const ctx1 = document.getElementById("chart-hourly")?.getContext("2d");
    if (ctx1) {
        new Chart(ctx1, {
            type: "bar",
            data: {
                labels: analytics.hourlyReservations.labels,
                datasets: [{
                    label: "Reservations",
                    data: analytics.hourlyReservations.data,
                    backgroundColor: "rgba(78, 52, 46, 0.85)",
                    borderRadius: 6
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // Chart 2: Busy Hours Trend (Line)
    const ctx2 = document.getElementById("chart-busy")?.getContext("2d");
    if (ctx2) {
        new Chart(ctx2, {
            type: "line",
            data: {
                labels: analytics.busyHoursTrend.labels,
                datasets: [{
                    label: "Footfall Trend",
                    data: analytics.busyHoursTrend.data,
                    borderColor: "#F59E0B",
                    backgroundColor: "rgba(245, 158, 11, 0.15)",
                    fill: true,
                    tension: 0.4
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // Chart 3: Table Occupancy (Pie)
    const ctx3 = document.getElementById("chart-occupancy")?.getContext("2d");
    if (ctx3) {
        new Chart(ctx3, {
            type: "doughnut",
            data: {
                labels: analytics.occupancyDistribution.labels,
                datasets: [{
                    data: analytics.occupancyDistribution.data,
                    backgroundColor: ["#EF4444", "#F59E0B", "#10B981"]
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // Chart 4: Revenue Estimation (Area)
    const ctx4 = document.getElementById("chart-revenue")?.getContext("2d");
    if (ctx4) {
        new Chart(ctx4, {
            type: "line",
            data: {
                labels: analytics.revenueTrend.labels,
                datasets: [{
                    label: "Estimated Revenue (₹)",
                    data: analytics.revenueTrend.data,
                    borderColor: "#10B981",
                    backgroundColor: "rgba(16, 185, 129, 0.2)",
                    fill: true,
                    tension: 0.3
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }
}

/* ==========================================================================
   8. Admin Dashboard Module & Controls
   ========================================================================== */
let adminStatusFilter = "All";
let adminSearchQuery = "";

function filterAdminTable(status) {
    adminStatusFilter = status;
    document.querySelectorAll(".admin-nav-list .admin-nav-item").forEach(item => item.classList.remove("active"));
    const buttons = document.querySelectorAll(".admin-nav-list .admin-nav-item button");
    buttons.forEach(btn => {
        if (btn.innerText.includes(status) || (status === 'All' && btn.innerText.includes('All Roster'))) {
            btn.parentElement.classList.add("active");
        }
    });
    renderAdminDashboard();
}

function handleAdminSearch(query) {
    adminSearchQuery = query.toLowerCase();
    renderAdminDashboard();
}

function renderAdminDashboard() {
    const tableBody = document.getElementById("admin-reservations-tbody");
    if (!tableBody) return;

    let res = window.cafeStore.getReservations();

    if (adminStatusFilter !== "All") {
        res = res.filter(r => r.status.toLowerCase() === adminStatusFilter.toLowerCase());
    }

    if (adminSearchQuery) {
        res = res.filter(r =>
            r.name.toLowerCase().includes(adminSearchQuery) ||
            r.phone.toLowerCase().includes(adminSearchQuery) ||
            r.id.toLowerCase().includes(adminSearchQuery)
        );
    }

    if (res.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 24px; color:var(--text-muted);">No matching reservations found.</td></tr>`;
        return;
    }

    tableBody.innerHTML = res.map(r => `
        <tr>
            <td style="font-weight:700;">${r.id}</td>
            <td><strong>${r.name}</strong><br><small style="color:var(--text-muted);">${r.phone}</small></td>
            <td>${r.date} @ ${r.time}</td>
            <td>Table ${r.tableNo} (${r.section})</td>
            <td>${r.guests} Guests</td>
            <td><span class="badge ${r.status === 'Seated' ? 'badge-info' : r.status === 'Confirmed' ? 'badge-success' : 'badge-warning'}">${r.status}</span></td>
            <td>
                <div style="display:flex; gap:6px;">
                    ${r.status === 'Confirmed' ? `<button class="btn btn-sm btn-primary" onclick="markReservationStatus('${r.id}', 'Seated')" title="Mark Guest Seated"><i class="fas fa-chair"></i> Seat</button>` : ''}
                    ${r.status === 'Seated' ? `<button class="btn btn-sm btn-secondary" onclick="markReservationStatus('${r.id}', 'Completed')" title="Mark Dining Complete"><i class="fas fa-check"></i> Complete</button>` : ''}
                    <button class="btn btn-sm btn-outline" onclick="deleteReservation('${r.id}')" title="Delete Booking"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join("");
}

async function markReservationStatus(id, newStatus) {
    await window.cafeStore.updateReservationStatus(id, newStatus);

    if (newStatus === "Seated") {
        const tables = window.cafeStore.getTables();
        const target = window.cafeStore.getReservations().find(r => r.id === id);
        if (target) {
            const table = tables.find(t => t.id === target.tableNo);
            if (table) {
                table.status = "occupied";
                table.guestName = target.name;
                await window.cafeStore.saveTables(tables);
            }
        }
    } else if (newStatus === "Completed") {
        const tables = window.cafeStore.getTables();
        const target = window.cafeStore.getReservations().find(r => r.id === id);
        if (target) {
            const table = tables.find(t => t.id === target.tableNo);
            if (table) {
                table.status = "available";
                table.guestName = null;
                table.reservedTime = null;
                await window.cafeStore.saveTables(tables);
            }
        }
    }

    populateTableSelect();
    renderFloorPlan();
    renderAdminDashboard();
    showToast(`Reservation ${id} updated to ${newStatus}`, "success");
}

async function deleteReservation(id) {
    await window.cafeStore.deleteReservation(id);
    renderAdminDashboard();
    showToast(`Reservation ${id} deleted`, "info");
}

function exportAdminRosterCSV() {
    const res = window.cafeStore.getReservations();
    if (!res || res.length === 0) {
        showToast("No reservations available to export.", "warning");
        return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Reservation ID,Guest Name,Phone,Email,Date,Time,Section,Table Number,Party Size,Status,Special Request\n";

    res.forEach(r => {
        const row = [
            `"${r.id}"`,
            `"${r.name}"`,
            `"${r.phone}"`,
            `"${r.email || ''}"`,
            `"${r.date}"`,
            `"${r.time}"`,
            `"${r.section}"`,
            `"${r.tableNo}"`,
            `"${r.guests}"`,
            `"${r.status}"`,
            `"${(r.specialRequest || '').replace(/"/g, '""')}"`
        ].join(",");
        csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `HM_Cafe_Reservations_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast("Reservation roster exported to CSV file!", "success");
}

function initDatePicker() {
    const dateInput = document.getElementById("res-date");
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
        if (!dateInput.value) dateInput.value = today;
    }
}

function showSMSNotification(phone, message) {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = "toast info";
    toast.style.background = "var(--primary-dark)";
    toast.style.color = "#FFFFFF";
    toast.style.borderLeft = "5px solid #00FFCC";
    toast.innerHTML = `<i class="fas fa-sms" style="color:#00FFCC; font-size:1.2rem;"></i> <div><strong style="font-size:0.75rem; display:block; opacity:0.8; text-transform:uppercase; letter-spacing:0.05em;">SMS ALERT TO ${phone}</strong><span style="font-size:0.9rem;">${message}</span></div>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => toast.remove(), 300);
    }, 6000);
}

/* ==========================================================================
   9. Helper Utilities, ScrollSpy & Event Delegation
   ========================================================================== */
function setupEventListeners() {
    // Theme toggle
    document.getElementById("theme-toggle-btn")?.addEventListener("click", toggleTheme);

    // Reservation form
    document.getElementById("reservation-form")?.addEventListener("submit", handleReservationSubmit);

    // Waitlist form
    document.getElementById("join-queue-form")?.addEventListener("submit", handleJoinWaitlist);

    // Floor plan filter tabs
    document.querySelectorAll(".filter-tabs .tab-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            document.querySelectorAll(".filter-tabs .tab-btn").forEach(b => b.classList.remove("active"));
            e.target.classList.add("active");
            renderFloorPlan(e.target.getAttribute("data-section"));
        });
    });

    // Mobile nav toggle
    const mobileToggle = document.getElementById("mobile-nav-toggle");
    const navLinksContainer = document.querySelector(".nav-links");
    if (mobileToggle && navLinksContainer) {
        mobileToggle.addEventListener("click", () => {
            navLinksContainer.classList.toggle("mobile-open");
            const icon = mobileToggle.querySelector("i");
            if (icon) {
                icon.className = navLinksContainer.classList.contains("mobile-open") ? "fas fa-times" : "fas fa-bars";
            }
        });
    }

    // FAQ Accordion
    document.querySelectorAll(".faq-question").forEach(q => {
        q.addEventListener("click", () => {
            const item = q.parentElement;
            item.classList.toggle("open");
        });
    });

    // Back to top button
    const backTop = document.getElementById("back-to-top");
    window.addEventListener("scroll", () => {
        if (window.scrollY > 400) backTop?.classList.add("visible");
        else backTop?.classList.remove("visible");
    });

    backTop?.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

function initScrollSpy() {
    const sections = document.querySelectorAll("section[id]");
    const navLinks = document.querySelectorAll(".nav-link");

    window.addEventListener("scroll", () => {
        let current = "";
        const scrollPosition = window.scrollY + 200;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                current = section.getAttribute("id");
            }
        });

        navLinks.forEach(link => {
            link.classList.remove("active");
            if (link.getAttribute("href") === `#${current}`) {
                link.classList.add("active");
            }
        });
    });
}

function openJoinQueueModal() {
    const modalHtml = `
        <div class="modal-overlay active" id="join-queue-modal">
            <div class="ticket-card">
                <div class="ticket-header">
                    <h3>Join Live Waitlist</h3>
                    <p style="font-size:0.85rem;">Get notified instantly when your table is ready</p>
                </div>
                <div class="ticket-body">
                    <form id="join-queue-form" onsubmit="handleJoinWaitlist(event)">
                        <div class="form-group" style="margin-bottom:16px;">
                            <label class="form-label">Customer Name</label>
                            <input type="text" id="queue-name" class="form-input" placeholder="Enter your full name" required>
                        </div>
                        <div class="form-group" style="margin-bottom:16px;">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" id="queue-phone" class="form-input" placeholder="+91 9876543210" required>
                        </div>
                        <div class="form-group" style="margin-bottom:24px;">
                            <label class="form-label">Number of Guests</label>
                            <select id="queue-guests" class="form-select">
                                <option value="1">1 Person</option>
                                <option value="2" selected>2 Guests</option>
                                <option value="4">4 Guests</option>
                                <option value="6">6+ Guests</option>
                            </select>
                        </div>
                        <div style="display:flex; gap:12px;">
                            <button type="submit" class="btn btn-primary" style="flex:1;">Join Waitlist</button>
                            <button type="button" class="btn btn-outline" onclick="closeModal('join-queue-modal')">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    document.getElementById("modal-container").innerHTML = modalHtml;
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove("active");
        setTimeout(() => modal.remove(), 300);
    }
}

function showToast(message, type = "info") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    const icon = type === "success" ? "check-circle" : type === "warning" ? "exclamation-triangle" : type === "danger" ? "times-circle" : "info-circle";

    toast.innerHTML = `<i class="fas fa-${icon}"></i> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

async function resetPresentationData() {
    if (confirm("Reset all tables, reservations, and queue data to initial demo state?")) {
        await window.cafeStore.resetAllData();
        populateTableSelect();
        renderFloorPlan();
        renderLiveQueue();
        renderSmartScreen();
        renderAdminDashboard();
        showToast("Demo data reset successfully!", "success");
    }
}
