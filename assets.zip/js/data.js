/**
 * HM Café - Data Engine & Backend REST API Connector
 * Smart Table Reservation & Queue Management System
 */

const DEFAULT_TABLES = [
    // Indoor Tables (T1 - T6)
    { id: 1, name: "Table 01", capacity: 2, section: "indoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 2, name: "Table 02", capacity: 2, section: "indoor", status: "occupied", reservedTime: "10:30 AM", guestName: "Rahul Sharma", phone: "+91 9876543210" },
    { id: 3, name: "Table 03", capacity: 4, section: "indoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 4, name: "Table 04", capacity: 4, section: "indoor", status: "reserved", reservedTime: "11:30 AM", guestName: "Priya Patel", phone: "+91 9812345678" },
    { id: 5, name: "Table 05", capacity: 6, section: "indoor", status: "occupied", reservedTime: "10:15 AM", guestName: "Amitabh Verma", phone: "+91 9988776655" },
    { id: 6, name: "Table 06", capacity: 2, section: "indoor", status: "available", reservedTime: null, guestName: null, phone: null },

    // Window View Tables (T7 - T12)
    { id: 7, name: "Table 07", capacity: 2, section: "window", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 8, name: "Table 08", capacity: 2, section: "window", status: "reserved", reservedTime: "12:00 PM", guestName: "Sneha Reddy", phone: "+91 9765432109" },
    { id: 9, name: "Table 09", capacity: 4, section: "window", status: "occupied", reservedTime: "10:00 AM", guestName: "David Miller", phone: "+91 9898989898" },
    { id: 10, name: "Table 10", capacity: 4, section: "window", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 11, name: "Table 11", capacity: 2, section: "window", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 12, name: "Table 12", capacity: 4, section: "window", status: "occupied", reservedTime: "10:45 AM", guestName: "Vikram Roy", phone: "+91 9123456789" },

    // Outdoor Garden Tables (T13 - T17)
    { id: 13, name: "Table 13", capacity: 4, section: "outdoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 14, name: "Table 14", capacity: 4, section: "outdoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 15, name: "Table 15", capacity: 6, section: "outdoor", status: "reserved", reservedTime: "01:15 PM", guestName: "Anita Desai", phone: "+91 9456789123" },
    { id: 16, name: "Table 16", capacity: 2, section: "outdoor", status: "occupied", reservedTime: "10:20 AM", guestName: "Rohan Gupta", phone: "+91 9321654987" },
    { id: 17, name: "Table 17", capacity: 4, section: "outdoor", status: "available", reservedTime: null, guestName: null, phone: null },

    // Premium VIP Booths (T18 - T20)
    { id: 18, name: "Table 18 (VIP)", capacity: 8, section: "vip", status: "reserved", reservedTime: "02:00 PM", guestName: "Malhotra Family", phone: "+91 9888877777" },
    { id: 19, name: "Table 19 (VIP)", capacity: 6, section: "vip", status: "occupied", reservedTime: "09:45 AM", guestName: "Dr. K. S. Nair", phone: "+91 9777766666" },
    { id: 20, name: "Table 20 (VIP)", capacity: 8, section: "vip", status: "available", reservedTime: null, guestName: null, phone: null }
];

const DEFAULT_QUEUE = [
    { id: "Q-101", name: "Ananya Sen", phone: "+91 9876123456", guests: 2, estWait: "10 mins", status: "Called", tableNo: 3, timestamp: "10:40 AM" },
    { id: "Q-102", name: "Suresh Menon", phone: "+91 9123987654", guests: 4, estWait: "15 mins", status: "Waiting", tableNo: "-", timestamp: "10:45 AM" },
    { id: "Q-103", name: "Kavita Rao", phone: "+91 9345678129", guests: 3, estWait: "22 mins", status: "Waiting", tableNo: "-", timestamp: "10:48 AM" },
    { id: "Q-104", name: "Manish Kumar", phone: "+91 9811223344", guests: 6, estWait: "30 mins", status: "Waiting", tableNo: "-", timestamp: "10:50 AM" },
    { id: "Q-105", name: "Sarah Jenkins", phone: "+91 9900112233", guests: 2, estWait: "38 mins", status: "Waiting", tableNo: "-", timestamp: "10:52 AM" }
];

const DEFAULT_RESERVATIONS = [
    { id: "RES-8921", name: "Rahul Sharma", phone: "+91 9876543210", email: "rahul@example.com", guests: 2, date: "2026-07-22", time: "10:30 AM", section: "Indoor", tableNo: 2, status: "Seated", specialRequest: "Corner quiet table" },
    { id: "RES-8922", name: "Priya Patel", phone: "+91 9812345678", email: "priya@example.com", guests: 4, date: "2026-07-22", time: "11:30 AM", section: "Indoor", tableNo: 4, status: "Confirmed", specialRequest: "Birthday decoration" },
    { id: "RES-8923", name: "Sneha Reddy", phone: "+91 9765432109", email: "sneha@example.com", guests: 2, date: "2026-07-22", time: "12:00 PM", section: "Window", tableNo: 8, status: "Confirmed", specialRequest: "Window side" },
    { id: "RES-8924", name: "Anita Desai", phone: "+91 9456789123", email: "anita@example.com", guests: 6, date: "2026-07-22", time: "01:15 PM", section: "Outdoor", tableNo: 15, status: "Confirmed", specialRequest: "High chair needed" },
    { id: "RES-8925", name: "Malhotra Family", phone: "+91 9888877777", email: "malhotra@example.com", guests: 8, date: "2026-07-22", time: "02:00 PM", section: "VIP", tableNo: 18, status: "Confirmed", specialRequest: "Anniversary celebration" }
];

const DEFAULT_ANALYTICS = {
    visitorsToday: 148,
    totalBookingsToday: 34,
    cancelledBookingsToday: 2,
    availableTablesCount: 10,
    avgWaitTimeMinutes: 18,
    occupancyRatePercentage: 50,
    satisfactionScore: 4.9,
    todayRevenueEstimated: "₹42,500",

    hourlyReservations: {
        labels: ["8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM", "2 PM", "3 PM", "4 PM", "5 PM", "6 PM", "7 PM", "8 PM", "9 PM"],
        data: [4, 8, 15, 22, 38, 45, 32, 18, 14, 25, 40, 48, 35, 12]
    },
    busyHoursTrend: {
        labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        data: [62, 58, 65, 72, 88, 98, 94]
    },
    occupancyDistribution: {
        labels: ["Occupied (30%)", "Reserved Soon (20%)", "Available (50%)"],
        data: [6, 4, 10]
    },
    revenueTrend: {
        labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
        data: [185000, 210000, 245000, 290000]
    }
};

class CafeDataStore {
    constructor() {
        this.apiBase = "/api";
        this.isBackendOnline = false;
        this.cache = {
            tables: null,
            queue: null,
            reservations: null,
            analytics: null
        };
        this.initLocalStorage();
    }

    initLocalStorage() {
        if (!localStorage.getItem("hm_cafe_tables")) {
            localStorage.setItem("hm_cafe_tables", JSON.stringify(DEFAULT_TABLES));
        }
        if (!localStorage.getItem("hm_cafe_queue")) {
            localStorage.setItem("hm_cafe_queue", JSON.stringify(DEFAULT_QUEUE));
        }
        if (!localStorage.getItem("hm_cafe_reservations")) {
            localStorage.setItem("hm_cafe_reservations", JSON.stringify(DEFAULT_RESERVATIONS));
        }
    }

    async checkBackend() {
        try {
            const res = await fetch(`${this.apiBase}/health`, { cache: "no-store" });
            if (res.ok) {
                const data = await res.json();
                this.isBackendOnline = true;
                this.updateServerStatusBadge(true);
                await this.syncFromBackend();
                return true;
            }
        } catch (e) {
            console.log("Backend API unreachable, using LocalStorage mode.");
        }
        this.isBackendOnline = false;
        this.updateServerStatusBadge(false);
        return false;
    }

    updateServerStatusBadge(online) {
        const badge = document.getElementById("server-status-badge");
        if (badge) {
            if (online) {
                badge.className = "badge badge-success-online";
                badge.innerHTML = `<i class="fas fa-database"></i> Backend: Connected (REST API)`;
            } else {
                badge.className = "badge badge-offline";
                badge.innerHTML = `<i class="fas fa-hdd"></i> Local Storage Mode`;
            }
        }
    }

    async syncFromBackend() {
        try {
            const [tables, queue, res, analytics] = await Promise.all([
                fetch(`${this.apiBase}/tables`).then(r => r.json()),
                fetch(`${this.apiBase}/queue`).then(r => r.json()),
                fetch(`${this.apiBase}/reservations`).then(r => r.json()),
                fetch(`${this.apiBase}/analytics`).then(r => r.json())
            ]);

            if (tables) {
                this.cache.tables = tables;
                localStorage.setItem("hm_cafe_tables", JSON.stringify(tables));
            }
            if (queue) {
                this.cache.queue = queue;
                localStorage.setItem("hm_cafe_queue", JSON.stringify(queue));
            }
            if (res) {
                this.cache.reservations = res;
                localStorage.setItem("hm_cafe_reservations", JSON.stringify(res));
            }
            if (analytics) {
                this.cache.analytics = analytics;
            }
        } catch (e) {
            console.warn("Failed syncing from backend server:", e);
        }
    }

    // --- Tables ---
    getTables() {
        if (this.cache.tables) return this.cache.tables;
        return JSON.parse(localStorage.getItem("hm_cafe_tables")) || DEFAULT_TABLES;
    }

    async saveTables(tables) {
        this.cache.tables = tables;
        localStorage.setItem("hm_cafe_tables", JSON.stringify(tables));
        if (this.isBackendOnline) {
            try {
                await fetch(`${this.apiBase}/tables`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(tables)
                });
            } catch (e) {
                console.warn("API saveTables failed:", e);
            }
        }
    }

    async updateSingleTable(id, updateData) {
        const tables = this.getTables();
        const index = tables.findIndex(t => t.id === id);
        if (index !== -1) {
            tables[index] = { ...tables[index], ...updateData };
            await this.saveTables(tables);
        }
    }

    // --- Queue ---
    getQueue() {
        if (this.cache.queue) return this.cache.queue;
        return JSON.parse(localStorage.getItem("hm_cafe_queue")) || DEFAULT_QUEUE;
    }

    async saveQueue(queue) {
        this.cache.queue = queue;
        localStorage.setItem("hm_cafe_queue", JSON.stringify(queue));
    }

    async addToQueue(item) {
        const queue = this.getQueue();
        queue.push(item);
        await this.saveQueue(queue);

        if (this.isBackendOnline) {
            try {
                await fetch(`${this.apiBase}/queue`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(item)
                });
            } catch (e) {
                console.warn("API addToQueue failed:", e);
            }
        }
    }

    async updateQueueStatus(id, newStatus, tableNo = null) {
        const queue = this.getQueue();
        const item = queue.find(q => q.id === id);
        if (item) {
            item.status = newStatus;
            if (tableNo !== null) item.tableNo = tableNo;
            await this.saveQueue(queue);

            if (this.isBackendOnline) {
                try {
                    await fetch(`${this.apiBase}/queue/${id}`, {
                        method: "PUT",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ status: newStatus, tableNo })
                    });
                } catch (e) {
                    console.warn("API updateQueueStatus failed:", e);
                }
            }
        }
    }

    async deleteQueueItem(id) {
        let queue = this.getQueue();
        queue = queue.filter(q => q.id !== id);
        await this.saveQueue(queue);

        if (this.isBackendOnline) {
            try {
                await fetch(`${this.apiBase}/queue/${id}`, { method: "DELETE" });
            } catch (e) {
                console.warn("API deleteQueueItem failed:", e);
            }
        }
    }

    // --- Reservations ---
    getReservations() {
        if (this.cache.reservations) return this.cache.reservations;
        return JSON.parse(localStorage.getItem("hm_cafe_reservations")) || DEFAULT_RESERVATIONS;
    }

    async saveReservations(reservations) {
        this.cache.reservations = reservations;
        localStorage.setItem("hm_cafe_reservations", JSON.stringify(reservations));
    }

    async addReservation(newRes) {
        const res = this.getReservations();
        res.unshift(newRes);
        await this.saveReservations(res);

        if (this.isBackendOnline) {
            try {
                await fetch(`${this.apiBase}/reservations`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(newRes)
                });
            } catch (e) {
                console.warn("API addReservation failed:", e);
            }
        }
    }

    async updateReservationStatus(id, newStatus) {
        const res = this.getReservations();
        const target = res.find(r => r.id === id);
        if (target) {
            target.status = newStatus;
            await this.saveReservations(res);

            if (this.isBackendOnline) {
                try {
                    await fetch(`${this.apiBase}/reservations/${id}`, {
                        method: "PUT",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ status: newStatus })
                    });
                } catch (e) {
                    console.warn("API updateReservationStatus failed:", e);
                }
            }
        }
    }

    async deleteReservation(id) {
        let res = this.getReservations();
        res = res.filter(r => r.id !== id);
        await this.saveReservations(res);

        if (this.isBackendOnline) {
            try {
                await fetch(`${this.apiBase}/reservations/${id}`, { method: "DELETE" });
            } catch (e) {
                console.warn("API deleteReservation failed:", e);
            }
        }
    }

    // --- Analytics ---
    getAnalytics() {
        const tables = this.getTables();
        const queue = this.getQueue();
        const res = this.getReservations();

        const availableCount = tables.filter(t => t.status === "available").length;
        const occupiedCount = tables.filter(t => t.status === "occupied").length;
        const reservedCount = tables.filter(t => t.status === "reserved").length;

        const occupancyRate = Math.round((occupiedCount / tables.length) * 100);

        return {
            ...DEFAULT_ANALYTICS,
            availableTablesCount: availableCount,
            occupancyRatePercentage: occupancyRate,
            totalBookingsToday: res.length + 29,
            occupancyDistribution: {
                labels: [`Occupied (${occupiedCount})`, `Reserved (${reservedCount})`, `Available (${availableCount})`],
                data: [occupiedCount, reservedCount, availableCount]
            }
        };
    }

    async resetAllData() {
        this.cache.tables = DEFAULT_TABLES;
        this.cache.queue = DEFAULT_QUEUE;
        this.cache.reservations = DEFAULT_RESERVATIONS;
        localStorage.setItem("hm_cafe_tables", JSON.stringify(DEFAULT_TABLES));
        localStorage.setItem("hm_cafe_queue", JSON.stringify(DEFAULT_QUEUE));
        localStorage.setItem("hm_cafe_reservations", JSON.stringify(DEFAULT_RESERVATIONS));

        if (this.isBackendOnline) {
            try {
                await fetch(`${this.apiBase}/reset`, { method: "POST" });
            } catch (e) {
                console.warn("API resetAllData failed:", e);
            }
        }
    }
}

window.cafeStore = new CafeDataStore();
