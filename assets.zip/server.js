const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "db.json");

app.use(cors());
app.use(express.json());

// Default Seed Data
const DEFAULT_TABLES = [
    { id: 1, name: "Table 01", capacity: 2, section: "indoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 2, name: "Table 02", capacity: 2, section: "indoor", status: "occupied", reservedTime: "10:30 AM", guestName: "Rahul Sharma", phone: "+91 9876543210" },
    { id: 3, name: "Table 03", capacity: 4, section: "indoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 4, name: "Table 04", capacity: 4, section: "indoor", status: "reserved", reservedTime: "11:30 AM", guestName: "Priya Patel", phone: "+91 9812345678" },
    { id: 5, name: "Table 05", capacity: 6, section: "indoor", status: "occupied", reservedTime: "10:15 AM", guestName: "Amitabh Verma", phone: "+91 9988776655" },
    { id: 6, name: "Table 06", capacity: 2, section: "indoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 7, name: "Table 07", capacity: 2, section: "window", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 8, name: "Table 08", capacity: 2, section: "window", status: "reserved", reservedTime: "12:00 PM", guestName: "Sneha Reddy", phone: "+91 9765432109" },
    { id: 9, name: "Table 09", capacity: 4, section: "window", status: "occupied", reservedTime: "10:00 AM", guestName: "David Miller", phone: "+91 9898989898" },
    { id: 10, name: "Table 10", capacity: 4, section: "window", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 11, name: "Table 11", capacity: 2, section: "window", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 12, name: "Table 12", capacity: 4, section: "window", status: "occupied", reservedTime: "10:45 AM", guestName: "Vikram Roy", phone: "+91 9123456789" },
    { id: 13, name: "Table 13", capacity: 4, section: "outdoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 14, name: "Table 14", capacity: 4, section: "outdoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 15, name: "Table 15", capacity: 6, section: "outdoor", status: "reserved", reservedTime: "01:15 PM", guestName: "Anita Desai", phone: "+91 9456789123" },
    { id: 16, name: "Table 16", capacity: 2, section: "outdoor", status: "occupied", reservedTime: "10:20 AM", guestName: "Rohan Gupta", phone: "+91 9321654987" },
    { id: 17, name: "Table 17", capacity: 4, section: "outdoor", status: "available", reservedTime: null, guestName: null, phone: null },
    { id: 18, name: "Table 18 (VIP)", capacity: 8, section: "vip", status: "reserved", reservedTime: "02:00 PM", guestName: "Malhotra Family", phone: "+91 9888877777" },
    { id: 19, name: "Table 19 (VIP)", capacity: 6, section: "vip", status: "occupied", reservedTime: "09:45 AM", guestName: "Dr. K. S. Nair", phone: "+91 9777766666" },
    { id: 20, name: "Table 20 (VIP)", capacity: 8, section: "vip", status: "available", reservedTime: null, guestName: null, phone: null }
];

const DEFAULT_QUEUE = [
    { id: "Q-101", name: "Ananya Sen", phone: "+91 9876123456", guests: 2, estWait: "10 mins", status: "Called", tableNo: 3, timestamp: "10:40 AM" },
    { id: "Q-102", name: "Suresh Menon", phone: "+91 9123987654", guests: 4, estWait: "15 mins", status: "Waiting", tableNo: "-", timestamp: "10:45 AM" },
    { id: "Q-103", name: "Kavita Rao", phone: "+91 9345678129", guests: 3, estWait: "22 mins", status: "Waiting", tableNo: "-", timestamp: "10:48 AM" },
    { id: "Q-104", name: "Manish Kumar", phone: "+91 9811223344", guests: 6, estWait: "30 mins", status: "Waiting", tableNo: "-", timestamp: "10:50 AM" },
    { id: "Q-105", name: "Sarah Jenkins", phone: "+91 9900112233", guests: 2, estWait: "38 mins", status: "Waiting", tableNo: "-", timestamp: "10:52 AM" }
];

const DEFAULT_RESERVATIONS = [
    { id: "RES-8921", name: "Rahul Sharma", phone: "+91 9876543210", email: "rahul@example.com", guests: 2, date: "2026-07-22", time: "10:30 AM", section: "Indoor", tableNo: 2, status: "Seated", specialRequest: "Corner quiet table" },
    { id: "RES-8922", name: "Priya Patel", phone: "+91 9812345678", email: "priya@example.com", guests: 4, date: "2026-07-22", time: "11:30 AM", section: "Indoor", tableNo: 4, status: "Confirmed", specialRequest: "Birthday decoration" },
    { id: "RES-8923", name: "Sneha Reddy", phone: "+91 9765432109", email: "sneha@example.com", guests: 2, date: "2026-07-22", time: "12:00 PM", section: "Window", tableNo: 8, status: "Confirmed", specialRequest: "Window side" },
    { id: "RES-8924", name: "Anita Desai", phone: "+91 9456789123", email: "anita@example.com", guests: 6, date: "2026-07-22", time: "01:15 PM", section: "Outdoor", tableNo: 15, status: "Confirmed", specialRequest: "High chair needed" },
    { id: "RES-8925", name: "Malhotra Family", phone: "+91 9888877777", email: "malhotra@example.com", guests: 8, date: "2026-07-22", time: "02:00 PM", section: "VIP", tableNo: 18, status: "Confirmed", specialRequest: "Anniversary celebration" }
];

const DEFAULT_ANALYTICS = {
    visitorsToday: 148,
    totalBookingsToday: 34,
    cancelledBookingsToday: 2,
    availableTablesCount: 10,
    avgWaitTimeMinutes: 18,
    occupancyRatePercentage: 50,
    satisfactionScore: 4.9,
    todayRevenueEstimated: "₹42,500",
    hourlyReservations: {
        labels: ["8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM", "2 PM", "3 PM", "4 PM", "5 PM", "6 PM", "7 PM", "8 PM", "9 PM"],
        data: [4, 8, 15, 22, 38, 45, 32, 18, 14, 25, 40, 48, 35, 12]
    },
    busyHoursTrend: {
        labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        data: [62, 58, 65, 72, 88, 98, 94]
    },
    revenueTrend: {
        labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
        data: [185000, 210000, 245000, 290000]
    }
};

// Database Initialization & Helper Functions
function readDb() {
    try {
        if (!fs.existsSync(DB_FILE)) {
            const initialData = {
                tables: DEFAULT_TABLES,
                queue: DEFAULT_QUEUE,
                reservations: DEFAULT_RESERVATIONS,
                analytics: DEFAULT_ANALYTICS
            };
            fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2));
            return initialData;
        }
        const dataStr = fs.readFileSync(DB_FILE, "utf-8");
        return JSON.parse(dataStr);
    } catch (err) {
        console.error("Error reading db.json, returning defaults:", err);
        return {
            tables: DEFAULT_TABLES,
            queue: DEFAULT_QUEUE,
            reservations: DEFAULT_RESERVATIONS,
            analytics: DEFAULT_ANALYTICS
        };
    }
}

function writeDb(data) {
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    } catch (err) {
        console.error("Error writing db.json:", err);
    }
}

// REST API Endpoints

// 1. System Health / Status
app.get("/api/health", (req, res) => {
    res.json({ status: "online", server: "HM Cafe Express REST Engine", timestamp: new Date().toISOString() });
});

// 2. Tables Endpoints
app.get("/api/tables", (req, res) => {
    const db = readDb();
    res.json(db.tables || DEFAULT_TABLES);
});

app.put("/api/tables/:id", (req, res) => {
    const tableId = parseInt(req.params.id, 10);
    const db = readDb();
    const index = db.tables.findIndex(t => t.id === tableId);
    if (index !== -1) {
        db.tables[index] = { ...db.tables[index], ...req.body };
        writeDb(db);
        return res.json({ success: true, table: db.tables[index] });
    }
    res.status(404).json({ error: "Table not found" });
});

app.put("/api/tables", (req, res) => {
    if (Array.isArray(req.body)) {
        const db = readDb();
        db.tables = req.body;
        writeDb(db);
        return res.json({ success: true, count: db.tables.length });
    }
    res.status(400).json({ error: "Invalid payload, array expected" });
});

// 3. Queue Endpoints
app.get("/api/queue", (req, res) => {
    const db = readDb();
    res.json(db.queue || DEFAULT_QUEUE);
});

app.post("/api/queue", (req, res) => {
    const newItem = req.body;
    const db = readDb();
    db.queue.push(newItem);
    writeDb(db);
    res.status(201).json({ success: true, item: newItem });
});

app.put("/api/queue/:id", (req, res) => {
    const queueId = req.params.id;
    const { status, tableNo } = req.body;
    const db = readDb();
    const item = db.queue.find(q => q.id === queueId);
    if (item) {
        if (status) item.status = status;
        if (tableNo !== undefined) item.tableNo = tableNo;
        writeDb(db);
        return res.json({ success: true, item });
    }
    res.status(404).json({ error: "Queue item not found" });
});

app.delete("/api/queue/:id", (req, res) => {
    const queueId = req.params.id;
    const db = readDb();
    db.queue = db.queue.filter(q => q.id !== queueId);
    writeDb(db);
    res.json({ success: true, deletedId: queueId });
});

// 4. Reservations Endpoints
app.get("/api/reservations", (req, res) => {
    const db = readDb();
    res.json(db.reservations || DEFAULT_RESERVATIONS);
});

app.post("/api/reservations", (req, res) => {
    const newRes = req.body;
    const db = readDb();
    db.reservations.unshift(newRes);
    writeDb(db);
    res.status(201).json({ success: true, reservation: newRes });
});

app.put("/api/reservations/:id", (req, res) => {
    const resId = req.params.id;
    const { status } = req.body;
    const db = readDb();
    const target = db.reservations.find(r => r.id === resId);
    if (target) {
        if (status) target.status = status;
        writeDb(db);
        return res.json({ success: true, reservation: target });
    }
    res.status(404).json({ error: "Reservation not found" });
});

app.delete("/api/reservations/:id", (req, res) => {
    const resId = req.params.id;
    const db = readDb();
    db.reservations = db.reservations.filter(r => r.id !== resId);
    writeDb(db);
    res.json({ success: true, deletedId: resId });
});

// 5. Analytics Endpoint
app.get("/api/analytics", (req, res) => {
    const db = readDb();
    const tables = db.tables || [];
    const queue = db.queue || [];
    const reservations = db.reservations || [];

    const availableCount = tables.filter(t => t.status === "available").length;
    const occupiedCount = tables.filter(t => t.status === "occupied").length;
    const reservedCount = tables.filter(t => t.status === "reserved").length;
    const occupancyRate = tables.length ? Math.round((occupiedCount / tables.length) * 100) : 0;

    const analytics = {
        ...(db.analytics || DEFAULT_ANALYTICS),
        availableTablesCount: availableCount,
        occupancyRatePercentage: occupancyRate,
        totalBookingsToday: reservations.length + 29,
        occupancyDistribution: {
            labels: [`Occupied (${occupiedCount})`, `Reserved (${reservedCount})`, `Available (${availableCount})`],
            data: [occupiedCount, reservedCount, availableCount]
        }
    };

    res.json(analytics);
});

// 6. Reset Data Endpoint
app.post("/api/reset", (req, res) => {
    const initialData = {
        tables: DEFAULT_TABLES,
        queue: DEFAULT_QUEUE,
        reservations: DEFAULT_RESERVATIONS,
        analytics: DEFAULT_ANALYTICS
    };
    writeDb(initialData);
    res.json({ success: true, message: "System database reset to initial defaults." });
});

// Static Files Server (Serves index.html, css, js)
app.use(express.static(path.join(__dirname)));

app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`HM Cafe Smart Backend Server running on http://localhost:${PORT}`);
    console.log(`API Health Check: http://localhost:${PORT}/api/health`);
    console.log(`=======================================================`);
});
